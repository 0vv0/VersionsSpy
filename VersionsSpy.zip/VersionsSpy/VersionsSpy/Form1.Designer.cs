﻿namespace VersionsSpy
{
    partial class VersionsSpy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VersionsSpy));
            this.wb1 = new System.Windows.Forms.WebBrowser();
            this.timerr = new System.Windows.Forms.Timer(this.components);
            this.tableHead = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.tableFooter = new System.Windows.Forms.Button();
            this.btnCheckAll = new System.Windows.Forms.Button();
            this.chbShowBaloon = new System.Windows.Forms.CheckBox();
            this.chbAutoCheck = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // wb1
            // 
            this.wb1.Dock = System.Windows.Forms.DockStyle.Right;
            this.wb1.Location = new System.Drawing.Point(655, 0);
            this.wb1.MinimumSize = new System.Drawing.Size(20, 20);
            this.wb1.Name = "wb1";
            this.wb1.ScriptErrorsSuppressed = true;
            this.wb1.Size = new System.Drawing.Size(305, 605);
            this.wb1.TabIndex = 0;
            this.wb1.TabStop = false;
            this.wb1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.wb1_DocumentCompleted);
            // 
            // timerr
            // 
            this.timerr.Interval = 1000;
            this.timerr.Tick += new System.EventHandler(this.timerr_Tick);
            // 
            // tableHead
            // 
            this.tableHead.Location = new System.Drawing.Point(12, 2);
            this.tableHead.Name = "tableHead";
            this.tableHead.Size = new System.Drawing.Size(559, 25);
            this.tableHead.TabIndex = 30;
            this.tableHead.Text = "Press for current version                              Current version           " +
    "                     Press to remember version";
            this.tableHead.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 30000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "There is no new version";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            // 
            // tableFooter
            // 
            this.tableFooter.Location = new System.Drawing.Point(577, 2);
            this.tableFooter.Name = "tableFooter";
            this.tableFooter.Size = new System.Drawing.Size(72, 25);
            this.tableFooter.TabIndex = 31;
            this.tableFooter.Text = "HELP";
            this.tableFooter.UseVisualStyleBackColor = true;
            this.tableFooter.Click += new System.EventHandler(this.tableFooter_Click);
            // 
            // btnCheckAll
            // 
            this.btnCheckAll.Location = new System.Drawing.Point(577, 33);
            this.btnCheckAll.Name = "btnCheckAll";
            this.btnCheckAll.Size = new System.Drawing.Size(75, 23);
            this.btnCheckAll.TabIndex = 32;
            this.btnCheckAll.Text = "Check ALL";
            this.btnCheckAll.UseVisualStyleBackColor = true;
            this.btnCheckAll.Click += new System.EventHandler(this.btnCheckAll_Click);
            // 
            // chbShowBaloon
            // 
            this.chbShowBaloon.AutoSize = true;
            this.chbShowBaloon.Location = new System.Drawing.Point(577, 62);
            this.chbShowBaloon.Name = "chbShowBaloon";
            this.chbShowBaloon.Size = new System.Drawing.Size(59, 17);
            this.chbShowBaloon.TabIndex = 33;
            this.chbShowBaloon.Text = "Baloon";
            this.chbShowBaloon.UseVisualStyleBackColor = true;
            this.chbShowBaloon.CheckedChanged += new System.EventHandler(this.chbShowBaloon_CheckedChanged);
            // 
            // chbAutoCheck
            // 
            this.chbAutoCheck.AutoSize = true;
            this.chbAutoCheck.Location = new System.Drawing.Point(577, 85);
            this.chbAutoCheck.Name = "chbAutoCheck";
            this.chbAutoCheck.Size = new System.Drawing.Size(78, 17);
            this.chbAutoCheck.TabIndex = 34;
            this.chbAutoCheck.Text = "Autocheck";
            this.chbAutoCheck.UseVisualStyleBackColor = true;
            this.chbAutoCheck.CheckedChanged += new System.EventHandler(this.chbAutoCheck_CheckedChanged);
            // 
            // VersionsSpy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(950, 622);
            this.Controls.Add(this.chbAutoCheck);
            this.Controls.Add(this.chbShowBaloon);
            this.Controls.Add(this.btnCheckAll);
            this.Controls.Add(this.tableFooter);
            this.Controls.Add(this.tableHead);
            this.Controls.Add(this.wb1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "VersionsSpy";
            this.Text = "VersionsSpy";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.VersionsSpy_FormClosing);
            this.Load += new System.EventHandler(this.VersionsSpy_Load);
            this.Resize += new System.EventHandler(this.VersionsSpy_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser wb1;
        private System.Windows.Forms.Timer timerr;
        private System.Windows.Forms.Button tableHead;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Button tableFooter;
        private System.Windows.Forms.Button btnCheckAll;
        private System.Windows.Forms.CheckBox chbShowBaloon;
        private System.Windows.Forms.CheckBox chbAutoCheck;
    }
}

