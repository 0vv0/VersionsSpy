﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using OpenQA.Selenium;
//using OpenQA.Selenium.IE;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
//using System.Reflection;

namespace VersionsSpy
{
    public partial class VersionsSpy : Form
    {
        private int NumberOfButtons = Properties.Settings.Default.URLS.Count;
        private int XforLeftColumn = Properties.Settings.Default.XforLeftColumn;
        private int YforFirstRaw = Properties.Settings.Default.YforFirstRaw;
        private int ButtonWidth = Properties.Settings.Default.ButtonWidth;
        private int ButtonHeight = Properties.Settings.Default.ButtonHeight;
        private int XforRightColumn = Properties.Settings.Default.XforRightColumn;
        private DateTime dt = DateTime.Now;
        public VersionsSpy()
        {
            InitializeComponent();
            int y = YforFirstRaw;
            for (int i = 0; i < NumberOfButtons; i++)
            {
                Button button = new Button(); Button btn = new Button();
                button.Location = new Point(XforLeftColumn, y); btn.Location = new Point(XforRightColumn, y);
                button.Size = new Size(ButtonWidth, ButtonHeight); btn.Size = new Size(ButtonWidth, ButtonHeight);
                button.Text = Properties.Settings.Default.Applications[i]; btn.Text = Properties.Settings.Default.Versions[i];
                button.Name = "button" + i.ToString(); btn.Name = "btn"+i.ToString();
                button.Click += new EventHandler(button_Click); btn.Click += new EventHandler(btn_Click);
                Controls.Add(button); Controls.Add(btn);
                y += ButtonHeight+5;
            }
        }
        private void VersionsSpy_Load(object sender, EventArgs e)
        {
            chbShowBaloon.Checked = Properties.Settings.Default.ShowBaloon;
            chbAutoCheck.Checked = Properties.Settings.Default.AutoCheck;
            timer1.Enabled = chbAutoCheck.Checked;
            wb1.Parent = this;
            wb1.Width = this.Width - Properties.Settings.Default.XforRightColumn - Properties.Settings.Default.ButtonWidth-5 ;
            wb1.Height = this.Height;
            wb1.ScriptErrorsSuppressed = Properties.Settings.Default.ScriptErrorsSuppressed ;           
            wb1.Navigate("about:blank");
            this.Text += " - " + Application.ProductVersion;
        }
        private void LoadVersion(int index)
        {
            this.Controls["btn"+index.ToString()].Text = Properties.Settings.Default.Versions[index];
        }
        private string GetQuickTime(string id, HtmlDocument hd)
        {
            if (hd.GetElementById(id) != null)
            {
                return hd.GetElementById(id).InnerText;
            }
            return "";
        }
        private string GetValueById(string id, HtmlDocument hd)
        {
            if (hd.GetElementById(id) != null && hd.GetElementById(id).GetAttribute("Value") != null)
            {
                return hd.GetElementById(id).GetAttribute("Value");
            }
            return "";
        }
        private string GetHREFById(string id, HtmlDocument hd)
        {
            if (hd.GetElementById(id) != null && hd.GetElementById(id).GetAttribute("HREF") != null)
            {
                return hd.GetElementById(id).GetAttribute("HREF");
            }
            return "";
        }
        private string GetValueByIdFromFrame(string id, string frameName)
        {

            if (wb1.Document.Window.Frames[frameName] != null && wb1.Document.Window.Frames[frameName].Document.GetElementById(id) != null && wb1.Document.Window.Frames[frameName].Document.GetElementById(id).GetAttribute("Value") != null)
            {
                return wb1.Document.Window.Frames[frameName].Document.GetElementById(id).GetAttribute("Value");
            }
            return "";
        }
        private string GetTextById(string id, HtmlDocument hd)
        {
            if (hd.GetElementById(id) != null)
            {
                return hd.GetElementById(id).InnerText;
            }
            return "";
        }
        private string GetHtmlById(string id, HtmlDocument hd)
        {
            if (hd.GetElementById(id) != null)
            {
                return hd.GetElementById(id).InnerHtml;
            }
            return "";
        }
        private string GetByTag(string id, int index, HtmlDocument hd)
        {
            if (hd!=null && hd.GetElementsByTagName(id)!=null)
            {
                return hd.GetElementsByTagName(id)[index].InnerText;
            }
            return "";
        }
        private string GetOpera(string id, HtmlDocument hd)
        {
            if (hd != null && hd.GetElementsByTagName(id) != null)
            {
                return hd.GetElementsByTagName(id).Cast<HtmlElement>().Last<HtmlElement>().InnerText;
            }
            return "";
        }
        private string GetByTagLastOne(string id,HtmlDocument hd)
        {
            if (hd.GetElementsByTagName(id) != null)
            {
                return hd.GetElementsByTagName(id)[hd.GetElementsByTagName(id).Count-1].InnerText;
            }
            return "";
        }
        private string GetByTagAttribute(string id, int index, string attributeName,HtmlDocument hd)
        {
            if (hd.GetElementsByTagName(id) != null)
            {
                return hd.GetElementsByTagName(id)[index].GetAttribute(attributeName);
            }
            return "";
        }
        private string GetByTagAndText(string id, string text,HtmlDocument hd)
        {
            if (hd!=null && hd.GetElementsByTagName(id) != null)
            {
                foreach (HtmlElement he in hd.GetElementsByTagName(id))
                {
                    if (he.InnerText != null && he.InnerText.Contains(text))
                    {
                        return he.InnerText.Substring(he.InnerText.IndexOf(text)+text.Length);
                    }
                }
                return "absent";
                //return hd.GetElementsByTagName(id).Cast<HtmlElement>().FirstOrDefault(p => p.InnerText.Contains(text)).InnerText;
            }
            return text + " absent";
        }
        private string GetByTagAndTextAndText(string id, string text, string text2, HtmlDocument hd)
        {
            if (hd != null && hd.GetElementsByTagName(id) != null)
            {
                foreach (HtmlElement he in hd.GetElementsByTagName(id))
                {
                    if (he.InnerText != null && he.InnerText.Contains(text) && he.InnerText.Contains(text2))
                    {
                        return he.InnerText.Substring(he.InnerText.IndexOf(text) + text.Length);
                    }
                }
               
            }
            return "";
        }
        private string GetByTagAndTextWithoutText(string id, string text, string exludedText, HtmlDocument hd)
        {
            if (hd != null && hd.GetElementsByTagName(id) != null)
            {
                foreach (HtmlElement he in hd.GetElementsByTagName(id))
                {
                    if (he.InnerText != null && he.InnerText.Contains(text) && !he.InnerText.Contains(exludedText))
                    {
                        return he.InnerText.Substring(he.InnerText.IndexOf(text) + text.Length);
                    }
                }
                
            }
            return "";
        }
        private string GetByText(string text, HtmlDocument hd){
            return GetByTagAndText("body", text, hd);
        }
        private string GetSubstringStartsFrom(string text, int index)
        {
            if (text.Length >= index) { return text.Substring(index); } else { return ""; }
        }
        private string GetByTagAndAttributeWithText(string id, string attributeName, string text,HtmlDocument hd)
        {
            if (hd.GetElementsByTagName(id) != null)
            {
                return hd.GetElementsByTagName(id).Cast<HtmlElement>().Where(p => p.GetAttribute(attributeName).Contains(text)).FirstOrDefault().InnerText;
            }
            return "";
        }
        private void VersionsSpy_FormClosing(object sender, FormClosingEventArgs e)
        {
            wb1.Dispose();wb1 = null;
        }
        private void VersionsSpy_Resize(object sender, EventArgs e)
        {
            wb1.Width = this.Width - Properties.Settings.Default.XforRightColumn - Properties.Settings.Default.ButtonWidth-5;
            wb1.Height = this.Height;
            //wb1.Left = Properties.Settings.Default.XforRightColumn + Properties.Settings.Default.ButtonWidth+5;
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Hide();
            }
        }
        private void wb1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            checkWebBrowserControl((WebBrowser)sender);
        }
        private void ShowVersions(string txt, int btnNumber)
        {
            txt = txt.Trim(); txt = txt.Split('\r')[0]; txt = txt.Split('\n')[0];
            if (this.Controls["l" + btnNumber.ToString()] != null) { this.Controls["l" + btnNumber.ToString()].Dispose(); }
            Label l = new Label();
            this.Controls.Add(l);
            l.Top = this.Controls["button" + btnNumber.ToString()].Top;
            l.Left = this.Controls["button" + btnNumber.ToString()].Left + ButtonWidth + 10;
            l.Width = ButtonWidth;
            l.Text =  txt;
            l.Visible = true;
            l.BorderStyle = BorderStyle.Fixed3D;
            l.Enabled = true;
            l.Name = "l" + btnNumber.ToString();
            if (chbShowBaloon.Checked && l.Text != this.Controls["btn" + btnNumber.ToString()].Text) 
            {
                notifyIcon1.ShowBalloonTip(3000, this.Controls["button" + btnNumber.ToString()].Text, l.Text,0); 
                notifyIcon1.Text = Properties.Settings.Default.baloonTextTrue;
            }
 
        }
        private void Navigate(int i)
        {
            wb1.Navigate(Properties.Settings.Default.URLS[i]);
        }
        private void button_Click(object sender, EventArgs e)
        {
            Navigate(Convert.ToInt16(((Button)sender).Name.Substring(6)));
        }          
        private void btn_Click(object sender, EventArgs e)
        {
            int index = Convert.ToInt16(((Button)sender).Name.Substring(3));
            if (this.Controls["l" + index.ToString()] != null)
            {
                Properties.Settings.Default.Versions[index] = this.Controls["l" + index.ToString()].Text;
                Properties.Settings.Default.Save();
                this.Controls["btn" + index.ToString()].Text = Properties.Settings.Default.Versions[index];
            }
        }
        private void timerr_Tick(object sender, EventArgs e)
        {
            if (wb1.Document.GetElementById(Properties.Settings.Default.MicrosoftSilverlightId) != null)
            {
                ShowVersions(GetTextById(Properties.Settings.Default.MicrosoftSilverlightId, wb1.Document), 8);
                timerr.Enabled = false;
            }
            if (wb1.Document.GetElementById(Properties.Settings.Default.MicrosoftSilverlightId2) != null)
            {
                ShowVersions(GetTextById(Properties.Settings.Default.MicrosoftSilverlightId2,wb1.Document).Split('\n')[1], 8);
                timerr.Enabled = false;
            }

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < NumberOfButtons; i++)
            {
                if (DateTime.Now.Minute == i) { Navigate(i); }
            } 
            checkWebBrowserControl(wb1);
        }
        private void checkWebBrowserControl(WebBrowser wb)
        {
            if (wb.Url.Host != null && wb.Url.Host != "" && !wb.IsBusy)
            {
                GetVersion(wb.Document, wb.Url.ToString());
            }
        }
        private void GetVersion(HtmlDocument hd, string url)
        {
            if (url.Contains(Properties.Settings.Default.URLS[0])) { ShowVersions(GetTextById(Properties.Settings.Default.AdobeFlashId, hd), 0); } //Adobe Flsah
            if (url.Contains(Properties.Settings.Default.URLS[1])) { ShowVersions(GetTextById(Properties.Settings.Default.AdobeReaderId, hd), 1); } //Adobe Reader
            if (url.Contains(Properties.Settings.Default.URLS[2])) { ShowVersions(GetTextById(Properties.Settings.Default.AdobeShockwaveId, hd), 2); } //Adobe Shockwave
            if (url.Contains(Properties.Settings.Default.URLS[3])) { ShowVersions(GetTextById(Properties.Settings.Default.AdobeAirId, hd), 3); } //Adobe Air
            if (url.Contains(Properties.Settings.Default.URLS[4])) { ShowVersions(GetByText(Properties.Settings.Default.OracleJavaId,hd), 4); } //Oracle Java
            if (url.Contains(Properties.Settings.Default.URLS[5])) { ShowVersions(GetByTagAndTextAndText(Properties.Settings.Default.AppleTag, Properties.Settings.Default.AppleiTunesText, Properties.Settings.Default.AppleiTunesText2, hd), 5); } //Apple iTunes                
            if (url.Contains(Properties.Settings.Default.URLS[6])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.AppleTag, Properties.Settings.Default.AppleQuickTimeText, hd), 6); } //Apple QuickTime 
            if (url.Contains(Properties.Settings.Default.URLS[7])) { ShowVersions(GetHREFById(Properties.Settings.Default.VideoLANVLCId, hd).Split('/')[4], 7); } //VideoLAN VLC
            if (url.Contains(Properties.Settings.Default.URLS[8])) { timerr.Enabled = true; } else { timerr.Enabled = false; } //Microsoft Silverlight
            if (url.Contains(Properties.Settings.Default.URLS[9])) { ShowVersions(GetByTag(Properties.Settings.Default.CanneverbeCDBurnerXPtag, Properties.Settings.Default.CanneverbeCDBurnerXPindex, hd), 9); } //Canneverbe CDBurner
            if (url.Contains(Properties.Settings.Default.URLS[10])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.Ghostscripttag, Properties.Settings.Default.Ghostscripttext, hd), 10); } //Ghostscript
            if (url.Contains(Properties.Settings.Default.URLS[11])) { ShowVersions(GetByTagAttribute(Properties.Settings.Default.MozillaFirefoxESRtag, Properties.Settings.Default.MozillaFirefoxESRindex, Properties.Settings.Default.MozillaFirefoxESRAttributeName, hd), 11); } //Mozilaa Firefox ESR
            if (url.Contains(Properties.Settings.Default.URLS[12])) { ShowVersions(GetByTag(Properties.Settings.Default.dotPDNPaintNettag, Properties.Settings.Default.dotPDNPaintNetid, hd), 12); } //dotPDN Paint.Net
            if (url.Contains(Properties.Settings.Default.URLS[13])) {ShowVersions(GetByTagAndTextWithoutText(Properties.Settings.Default.FileZillatag, Properties.Settings.Default.FileZillaText, Properties.Settings.Default.FileZillaExluded, hd), 13);} //FileZilla
            if (url.Contains(Properties.Settings.Default.URLS[14])) { ShowVersions(GetByTag(Properties.Settings.Default.ZipTag, Properties.Settings.Default.ZipIndex, hd), 14); } //7-Zip
            if (url.Contains(Properties.Settings.Default.URLS[15])) { ShowVersions(GetByTagLastOne(Properties.Settings.Default.FoxitTag, hd), 15); } //Foxit Reader
            if (url.Contains(Properties.Settings.Default.URLS[16])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.FreePDFTag, Properties.Settings.Default.FreePDFText, hd), 16); } //FreePDF
            if (url.Contains(Properties.Settings.Default.URLS[17])){ShowVersions(GetByTagAndText(Properties.Settings.Default.GoogleChromeTag, Properties.Settings.Default.GoogleChromeText, hd), 17); } //Chrome
            if (url.Contains(Properties.Settings.Default.URLS[18])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.KeePassTag, Properties.Settings.Default.KeePassText, hd), 18); } //KeePass
            if (url.Contains(Properties.Settings.Default.URLS[19])) { ShowVersions(GetByTag(Properties.Settings.Default.NotepadPlusPlusTag, 0, hd), 19); } //Notepad++
            if (url.Contains(Properties.Settings.Default.URLS[20])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.WireSharkTag, Properties.Settings.Default.WireSharkText, hd), 20); } //WireShark
            if (url.Contains(Properties.Settings.Default.URLS[21])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.PuttyTag, Properties.Settings.Default.PuttyText, hd), 21); } //Putty
            if (url.Contains(Properties.Settings.Default.URLS[22])) { ShowVersions(GetByTag(Properties.Settings.Default.WinSCPTag, Properties.Settings.Default.WinSCPIndex, hd), 22); } //WinSCP
            if (url.Contains(Properties.Settings.Default.URLS[23])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.DbVisualizerTag, Properties.Settings.Default.DbVisualizerText, hd), 23); } //DbVis DbVisualizer
            if (url.Contains(Properties.Settings.Default.URLS[24])) { ShowVersions(GetByTagAndAttributeWithText(Properties.Settings.Default.FreeMindTag, Properties.Settings.Default.FreeMindAttributeName, Properties.Settings.Default.FreeMindAttributeValue, hd), 24); } //FreeMind
            if (url.Contains(Properties.Settings.Default.URLS[25])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.TortoiseGitTag, Properties.Settings.Default.TortoiseGitText, hd), 25); } //TortoiseGit
            if (url.Contains(Properties.Settings.Default.URLS[26])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.TortoiseSVNTag, Properties.Settings.Default.TortoiseSVNText, hd), 26); } //TortoiseSVN
            if (url.Contains(Properties.Settings.Default.URLS[27])) { ShowVersions(GetByTagAndText(Properties.Settings.Default.GreenshotTag, Properties.Settings.Default.GreenshotText, hd), 27); } //Greenshot
            if (url.Contains(Properties.Settings.Default.URLS[28])) { ShowVersions(GetOpera(Properties.Settings.Default.OperaTag, hd), 28); } //Opera
        }
        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            this.Show();
        } 
        private void tableFooter_Click(object sender, EventArgs e)
        {
            Form f2 = new Form();            
            f2.Owner = this;
            f2.Text = "HELP"; 
            
            Label lHelp = new Label();
            lHelp.Parent = f2;
            lHelp.Top = f2.Top;
            lHelp.Left = f2.Left;
            lHelp.Width= f2.Width-1;
            lHelp.Height= f2.Height-1;            
            lHelp.Text = "1. Wait for 1 hour\r\n";
            lHelp.Text += "2. Press button in right column to remember the version\r\n";
            lHelp.Show();
            f2.ShowDialog();
        }
        private HtmlDocument GetHtmlDocument(string html)
        {
            WebBrowser browser = new WebBrowser();
            HtmlDocument hd;
            browser.ScriptErrorsSuppressed = true;
            browser.Visible = false;
            browser.DocumentText = html;
            browser.Document.OpenNew(true);
            browser.Document.Write(html);
            browser.Refresh();
            hd = browser.Document;
            browser.Dispose();
            return hd;
        }
        private void btnCheckAll_Click(object sender, EventArgs e)
        {
            IWebDriver driver = new ChromeDriver();
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(10));
            for (int i = 0; i < Properties.Settings.Default.URLS.Count; i++)
            {
                driver.Url = Properties.Settings.Default.URLS[i];
                try
                {
                    WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
                    IWebElement iwe = wait.Until<IWebElement>((d) => { return d.FindElement(By.TagName("body")); });
                    if (driver.Url != "")
                    {
                        GetVersion(GetHtmlDocument(driver.PageSource), driver.Url.ToString());
                    }
                }
                catch { }
            }
            driver.Close();
            driver.Dispose();
        }
        private void chbAutoCheck_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.AutoCheck = chbAutoCheck.Checked;
            Properties.Settings.Default.Save();
            if (Properties.Settings.Default.AutoCheck) { timer1.Enabled = true; } else { timer1.Enabled = false; }
        }
        private void chbShowBaloon_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default.ShowBaloon = chbShowBaloon.Checked;
            Properties.Settings.Default.Save();
        }
    }
}
